import { motion, useMotionValue, useScroll, useSpring, useTransform } from "framer-motion";
import {
  ArrowDownRight,
  ArrowUpRight,
  Asterisk,
  Instagram,
  Menu,
  Plus,
  X,
} from "lucide-react";
import { useEffect, useState } from "react";

const HERO_IMAGE = "/manus-storage/world-studios-usc-hero_8225f0be.jpg";
const PROCESS_IMAGE = "/manus-storage/world-studios-usc-process_62318ae2.jpg";
const STICKER_IMAGE = "/manus-storage/world-studios-usc-sticker_01b18205.png";

const signals = [
  {
    number: "01",
    title: "Care is a practice",
    copy: "We notice what is overlooked, then build with—not for—the people closest to it.",
    hue: "red",
    tag: "community-led",
  },
  {
    number: "02",
    title: "Make the future testable",
    copy: "A weird prototype today can become a better system tomorrow. We start before we are ready.",
    hue: "blue",
    tag: "rough + real",
  },
  {
    number: "03",
    title: "Cross the room",
    copy: "Designers, researchers, organizers, engineers, and useful troublemakers all belong at the table.",
    hue: "lime",
    tag: "all disciplines",
  },
];

const activities = [
  ["01", "Friction walks", "Find the tiny annoyances hiding in plain sight."],
  ["02", "Field notes", "Get outside the classroom. Ask better questions."],
  ["03", "Build sessions", "Make the thing. Break it. Make it legible."],
  ["04", "Show & tells", "Share the work while it is still changing."],
];

const marquee = "MAKE WHAT MATTERS — MAKE WHAT MATTERS — MAKE WHAT MATTERS — ";

const workshops = [
  { id: "01", kind: "WORKSHOP", title: "Designing with, not for", detail: "A hands-on introduction to community-led design.", timing: "FALL 2026 · DATE TO BE ANNOUNCED", color: "coral" },
  { id: "02", kind: "OPEN STUDIO", title: "The prototype playground", detail: "Bring a half-formed idea. Leave with something you can test.", timing: "FALL 2026 · DATE TO BE ANNOUNCED", color: "blue" },
  { id: "03", kind: "FIELD SESSION", title: "Notice your neighborhood", detail: "A guided walk to spot friction, possibility, and the stories in between.", timing: "FALL 2026 · DATE TO BE ANNOUNCED", color: "yellow" },
];

const portals = [
  { id: "origin", number: "01", label: "THE RELAUNCH", peek: "A STUDIO CAN ALWAYS BEGIN AGAIN.", copy: "Pick up the story that started in 2015, went quiet, and comes back as World Studios USC.", href: "#about", cta: "SEE THE RELAUNCH", style: "coral" },
  { id: "practice", number: "02", label: "THE PRACTICE", peek: "MAKE ROOM FOR A BETTER QUESTION.", copy: "A look inside our way of working: listen closely, test early, and make together.", href: "#practice", cta: "STEP INTO THE STUDIO", style: "blue" },
  { id: "workshops", number: "03", label: "WHAT'S NEXT", peek: "THE NEXT IDEA COULD BE YOURS.", copy: "Workshops and open-studio sessions are being planned for Fall 2026. Exact dates will be added once confirmed.", href: "#events", cta: "SEE WHAT'S COMING", style: "yellow" },
];

function usePointer() {
  const x = useMotionValue(-100);
  const y = useMotionValue(-100);
  const turn = useMotionValue(0);
  const smoothX = useSpring(x, { stiffness: 360, damping: 34, mass: 0.35 });
  const smoothY = useSpring(y, { stiffness: 360, damping: 34, mass: 0.35 });
  const smoothTurn = useSpring(turn, { stiffness: 180, damping: 23, mass: 0.55 });

  useEffect(() => {
    let lastX = -100;
    let lastY = -100;
    let cumulativeTurn = 0;
    const updatePointer = (event: PointerEvent) => {
      if (event.pointerType === "touch") return;
      x.set(event.clientX - 23);
      y.set(event.clientY - 23);
      const target = document.elementFromPoint(event.clientX, event.clientY);
      document.body.classList.toggle("cursor-hover", !!target?.closest("a, button"));
      if (lastX >= 0) {
        const dx = event.clientX - lastX;
        cumulativeTurn += Math.hypot(dx, event.clientY - lastY) * 0.85;
        turn.set(cumulativeTurn);
      }
      lastX = event.clientX;
      lastY = event.clientY;
    };
    const leaveWindow = () => document.body.classList.remove("cursor-hover");
    window.addEventListener("pointermove", updatePointer, { passive: true });
    document.documentElement.addEventListener("pointerleave", leaveWindow);
    return () => {
      window.removeEventListener("pointermove", updatePointer);
      document.documentElement.removeEventListener("pointerleave", leaveWindow);
      document.body.classList.remove("cursor-hover");
    };
  }, []);

  return { x: smoothX, y: smoothY, rotate: smoothTurn };
}

export default function Home() {
  const [menuOpen, setMenuOpen] = useState(false);
  const [navSolid, setNavSolid] = useState(false);
  const pointerStyle = usePointer();
  const { scrollY, scrollYProgress } = useScroll();
  const heroShift = useTransform(scrollY, [0, 800], [0, 130]);
  const heroScale = useTransform(scrollY, [0, 700], [1, 1.08]);
  const progress = useSpring(scrollYProgress, { stiffness: 120, damping: 30, restDelta: 0.001 });
  const stopOneOpacity = useTransform(progress, [0.54, 0.59], [0, 1]);
  const stopTwoOpacity = useTransform(progress, [0.58, 0.63], [0, 1]);
  const stopThreeOpacity = useTransform(progress, [0.62, 0.67], [0, 1]);
  const stopOpacities = [stopOneOpacity, stopTwoOpacity, stopThreeOpacity];
  const [openPortal, setOpenPortal] = useState<string | null>(null);

  useEffect(() => {
    const onScroll = () => setNavSolid(window.scrollY > 100);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  useEffect(() => {
    document.body.style.overflow = menuOpen ? "hidden" : "";
    return () => {
      document.body.style.overflow = "";
    };
  }, [menuOpen]);

  useEffect(() => {
    if (!openPortal) return;
    document.getElementById(`portal-close-${openPortal}`)?.focus({ preventScroll: true });
    const closeOnEscape = (event: KeyboardEvent) => {
      if (event.key === "Escape") {
        setOpenPortal(null);
        requestAnimationFrame(() => document.getElementById(`portal-trigger-${openPortal}`)?.focus());
      }
    };
    window.addEventListener("keydown", closeOnEscape);
    return () => window.removeEventListener("keydown", closeOnEscape);
  }, [openPortal]);

  useEffect(() => {
    const targets = document.querySelectorAll(".reveal, .activity, .studio-collage, .portal-card, .events-heading, .event-card, .social-window, .social-card");
    const observer = new IntersectionObserver((entries) => {
      entries.forEach((entry) => {
        if (entry.isIntersecting) {
          entry.target.classList.add("is-visible");
          observer.unobserve(entry.target);
        }
      });
    }, { threshold: 0.14, rootMargin: "0px 0px -35px 0px" });
    targets.forEach((target) => observer.observe(target));
    return () => observer.disconnect();
  }, []);

  return (
    <main className="site-shell" id="top">
      <motion.div className="scroll-indicator" style={{ scaleX: progress }} />
      <motion.div className="cursor-orbit" aria-hidden="true" style={pointerStyle}>
        <img className="cursor-wheel" src={STICKER_IMAGE} alt="" />
      </motion.div>
      <div className="opportunity-thread" aria-hidden="true">
        <svg viewBox="0 0 1000 1000" preserveAspectRatio="none">
          <defs>
            <linearGradient id="thread-gradient" x1="0" y1="0" x2="1" y2="1">
              <stop offset="0%" stopColor="#f13c29" />
              <stop offset="32%" stopColor="#d9ff62" />
              <stop offset="63%" stopColor="#2446ff" />
              <stop offset="100%" stopColor="#f13c29" />
            </linearGradient>
          </defs>
          <motion.path className="thread-glow" d="M900 0 C700 34 110 54 130 99 C150 147 855 160 865 202 C875 248 170 267 154 315 C137 363 824 377 845 423 C868 469 185 487 161 533 C135 578 805 580 850 620 C810 646 700 629 500 620 C335 612 241 645 150 620 C130 667 823 685 849 731 C877 777 181 798 153 846 C125 894 740 930 875 1000" style={{ pathLength: progress }} />
          <motion.path className="thread-line" d="M900 0 C700 34 110 54 130 99 C150 147 855 160 865 202 C875 248 170 267 154 315 C137 363 824 377 845 423 C868 469 185 487 161 533 C135 578 805 580 850 620 C810 646 700 629 500 620 C335 612 241 645 150 620 C130 667 823 685 849 731 C877 777 181 798 153 846 C125 894 740 930 875 1000" style={{ pathLength: progress }} />
          <path className="thread-opportunity-branch" d="M150 620 C300 580 410 586 500 620 C610 664 730 665 850 620" />
          {[210, 500, 790].map((x, i) => (
            <motion.g className="thread-stop" style={{ opacity: stopOpacities[i], scale: stopOpacities[i] }} transform={`translate(${x} 620)`} key={x}>
              <circle r="17" />
              <text y="5">✳</text>
              <title>{`New opportunity ${i + 1}`}</title>
            </motion.g>
          ))}
        </svg>
      </div>

      <header className={`site-nav ${navSolid ? "site-nav--solid" : ""}`}>
        <a className="wordmark" href="#top" aria-label="World Studios USC home">
          <span className="wordmark-mark">✳</span>
          <span>WORLD STUDIOS</span>
          <small>USC</small>
        </a>
        <div className="nav-center" aria-label="Site sections">
          <a href="#about">The relaunch</a>
          <a href="#practice">The practice</a>
          <a href="#explore">Windows</a>
          <a href="#events">Events</a>
          <a href="#join">Join in</a>
        </div>
        <button
          className="nav-menu"
          onClick={() => setMenuOpen(true)}
          aria-label="Open navigation"
          type="button"
        >
          <span>MENU</span><Menu size={18} strokeWidth={2.6} />
        </button>
      </header>

      <div className={`menu-sheet ${menuOpen ? "menu-sheet--open" : ""}`} aria-hidden={!menuOpen}>
        <div className="menu-sheet-top">
          <span className="menu-label">WORLD STUDIOS / USC</span>
          <button className="menu-close" type="button" onClick={() => setMenuOpen(false)} aria-label="Close navigation">
            <X size={28} />
          </button>
        </div>
        <nav className="menu-links">
          {[
            ["01", "The relaunch", "#about"],
            ["02", "The practice", "#practice"],
            ["03", "Peek through a window", "#explore"],
            ["04", "Workshops & feed", "#events"],
            ["05", "Join the studio", "#join"],
          ].map(([number, label, href]) => (
            <a key={number} href={href} onClick={() => setMenuOpen(false)}>
              <span>{number}</span><strong>{label}</strong><ArrowDownRight />
            </a>
          ))}
        </nav>
        <p className="menu-foot">Los Angeles, California<br />University of Southern California</p>
      </div>

      <section className="hero" aria-labelledby="hero-title">
        <div className="hero-grid" />
        <div className="hero-corner hero-corner--tl">A student-run social impact design studio</div>
        <div className="hero-corner hero-corner--tr">EST. 2015<br />RE/START 2026</div>
        <motion.div className="hero-visual" style={{ y: heroShift, scale: heroScale }}>
          {HERO_IMAGE ? <img src={HERO_IMAGE} alt="Experimental World Studios USC artwork" /> : <HeroGraphic />}
          <div className="visual-stamp">WS<br />USC</div>
          <div className="visual-lens" />
        </motion.div>
        <div className="hero-title-wrap">
          <motion.p
            className="eyebrow hero-eyebrow"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.7, delay: 0.3 }}
          >
            FIELD NOTES FROM A RELAUNCH
          </motion.p>
          <h1 id="hero-title">
            <motion.span
              initial={{ opacity: 0, y: 80, rotate: 2 }}
              animate={{ opacity: 1, y: 0, rotate: 0 }}
              transition={{ duration: 0.8, delay: 0.05, ease: [0.23, 1, 0.32, 1] }}
            >WE MAKE</motion.span>
            <motion.em
              initial={{ opacity: 0, y: 80, rotate: -2 }}
              animate={{ opacity: 1, y: 0, rotate: 0 }}
              transition={{ duration: 0.8, delay: 0.17, ease: [0.23, 1, 0.32, 1] }}
            >WHAT</motion.em>
            <motion.span
              initial={{ opacity: 0, y: 80, rotate: 2 }}
              animate={{ opacity: 1, y: 0, rotate: 0 }}
              transition={{ duration: 0.8, delay: 0.29, ease: [0.23, 1, 0.32, 1] }}
            >MATTERS.</motion.span>
          </h1>
        </div>
        <div className="hero-bottom">
          <p>World Studios USC is back. A space to turn care, curiosity, and a little chaos into things that move Los Angeles forward.</p>
          <a className="round-scroll" href="#about" aria-label="Scroll to relaunch story"><ArrowDownRight size={29} /></a>
        </div>
      </section>

      <section className="ticker" aria-label="World Studios ethos">
        <div className="ticker-track"><span>{marquee}</span><span>{marquee}</span></div>
      </section>

      <section className="relaunch section-pad" id="about">
        <div className="section-index"><span>(01)</span><span>THE RELAUNCH</span></div>
        <div className="relaunch-layout">
          <div className="relaunch-intro reveal">
            <p className="eyebrow">NOT NEW. NEW AGAIN.</p>
            <h2>Same spark.<br /><i>New constellation.</i></h2>
            <p className="lead">From 2015–2023, Design for America at USC was a home for students who thought design could be a public good. We went quiet. The world did not. Now we are relaunching as <strong>World Studios USC</strong>.</p>
          </div>
          <div className="timeline">
            <div className="timeline-line" />
            <article className="timeline-item reveal">
              <span className="time">2015—23</span>
              <h3>The first chapter</h3>
              <p>Students built thoughtful projects, learned in public, and put care at the center of their practice.</p>
            </article>
            <article className="timeline-item timeline-item--now reveal">
              <span className="time">FALL 2026</span>
              <h3>The signal returns</h3>
              <p>A new crew. A global network. A studio designed for the urgency of right now.</p>
              <span className="pulse-dot" aria-hidden="true" />
            </article>
          </div>
        </div>
        <div className="relaunch-footer">
          <span>PART OF A GLOBAL NETWORK OF STUDENT-LED STUDIOS</span>
          <a href="https://www.world-studios.org/" target="_blank" rel="noreferrer">ABOUT WORLD STUDIOS <ArrowUpRight size={15} /></a>
        </div>
      </section>

      <section className="manifesto" id="practice">
        <div className="manifesto-rule" />
        <div className="manifesto-header section-pad">
          <div className="section-index section-index--light"><span>(02)</span><span>THE PRACTICE</span></div>
          <p className="manifesto-micro">This is where sharp ideas get their hands dirty.</p>
        </div>
        <div className="manifesto-statement section-pad">
          <p>We are a studio for people who want to</p>
          <h2><span>notice</span> more,<br /><i>make</i> together,<br />and <span>leave a mark</span>.</h2>
        </div>
        <div className="signal-grid section-pad">
          {signals.map((signal, index) => (
            <motion.article
              className={`signal-card signal-card--${signal.hue}`}
              key={signal.number}
              initial={{ opacity: 0, y: 42 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, amount: 0.3 }}
              transition={{ duration: 0.65, delay: index * 0.08, ease: [0.23, 1, 0.32, 1] }}
            >
              <div className="signal-top"><span>{signal.number}</span><Plus size={22} /></div>
              <div className="signal-copy"><span className="tag">{signal.tag}</span><h3>{signal.title}</h3><p>{signal.copy}</p></div>
              <div className="signal-shape" />
            </motion.article>
          ))}
        </div>
      </section>

      <section className="studio-day section-pad" aria-labelledby="studio-day-title">
        <div className="studio-day-title">
          <div className="section-index"><span>(03)</span><span>IN THE STUDIO</span></div>
          <h2 id="studio-day-title">NO SPECTATORS.</h2>
          <p>Come for the people, stay for the experiments. Our studio is a place to find an opening and start pulling on it.</p>
        </div>
        <div className="studio-collage">
          <div className="collage-photo">
            {PROCESS_IMAGE ? <img src={PROCESS_IMAGE} alt="Hands at work in a design studio" /> : <ProcessGraphic />}
          </div>
          <div className="collage-blue">MAKE<br />IT<br />REAL.</div>
          <div className="collage-note">NO PERFECT<br />FIRST DRAFTS</div>
          <div className="collage-pin" />
        </div>
      <div className="activity-list">
          {activities.map(([number, title, copy]) => (
            <article className="activity" key={number}>
              <span>{number}</span><h3>{title}</h3><p>{copy}</p><ArrowUpRight size={21} />
            </article>
          ))}
        </div>
      </section>

      <section className="portals section-pad" id="explore">
        <div className="section-index"><span>(04)</span><span>TAKE A CLOSER LOOK</span></div>
        <div className="portals-heading">
          <div><p className="eyebrow">A VIEW IS NOT AN INVITATION. OPEN IT.</p><h2>Some things<br />start with a <i>peek.</i></h2></div>
          <p>Pick a window. Look in. When you’re ready, open a little more possibility.</p>
        </div>
        <div className="portal-grid">
          {portals.map((portal) => {
            const isOpen = openPortal === portal.id;
            return (
              <motion.article layout transition={{ layout: { type: "spring", stiffness: 210, damping: 25 } }} className={`portal-card portal-card--${portal.style} ${isOpen ? "portal-card--open" : ""}`} key={portal.id}>
                <div className="portal-card-stage">
                  <div className="portal-room" role="region" aria-label={`${portal.label} opportunity window`} aria-hidden={!isOpen} inert={!isOpen}>
                    <img className="portal-room-image" src={PROCESS_IMAGE} alt="" />
                    <div className="portal-room-top"><span>{portal.number} / {portal.label}</span><button id={`portal-close-${portal.id}`} type="button" className="portal-room-close" aria-label="Close window" onClick={() => { setOpenPortal(null); requestAnimationFrame(() => document.getElementById(`portal-trigger-${portal.id}`)?.focus()); }}><X size={17} /></button></div>
                    <span className="portal-room-star" aria-hidden="true">✳</span>
                    <div className="portal-room-copy"><p className="eyebrow">A NEW OPENING AT USC</p><h3>{portal.peek}</h3><p>{portal.copy}</p></div>
                    <a className="portal-room-link" href={portal.href} onClick={() => setOpenPortal(null)}>{portal.cta}<ArrowUpRight size={18} /></a>
                    <span className="portal-room-footer">WORLD STUDIOS / USC · FALL 2026</span>
                  </div>
                  <button
                    id={`portal-trigger-${portal.id}`}
                    className="portal-door"
                    type="button"
                    aria-expanded={isOpen}
                    aria-label={`${isOpen ? "Close" : "Open"} ${portal.label.toLowerCase()} window`}
                    tabIndex={isOpen ? -1 : 0}
                    onClick={() => setOpenPortal(isOpen ? null : portal.id)}
                  >
                    <span className="portal-window-top"><span>WS / USC</span><span>{portal.number}</span></span>
                    <span className="portal-window-glass"><i /><i /><b>{portal.peek}</b><span className="portal-glass-star">✳</span></span>
                    <span className="portal-door-bottom"><span>{isOpen ? "OPEN / WINDOW REVEALED" : "CLOSED / TAP TO OPEN"}</span><span className="portal-handle" /></span>
                  </button>
                </div>
                <p className="portal-caption"><span>{portal.label}</span><span>{isOpen ? "OPEN" : "PEEK THROUGH"}</span></p>
                <p className="portal-description">{portal.copy}</p>
              </motion.article>
            );
          })}
        </div>
      </section>

      <section className="events-social section-pad" id="events">
        <div className="section-index"><span>(05)</span><span>UPCOMING / FALL 2026</span></div>
        <div className="events-heading">
          <div><p className="eyebrow">THE FIRST STUDIO CALENDAR</p><h2>MAKE A<br /><i>little noise.</i></h2></div>
          <p>Workshops, field sessions, and open studio hours are taking shape. These are planned sessions; confirmed dates and RSVP links will appear here as soon as they are set.</p>
        </div>
        <div className="events-layout">
          <div className="event-list" aria-label="Upcoming studio events">
            {workshops.map((event) => (
              <article className={`event-card event-card--${event.color}`} key={event.id}>
                <div className="event-meta"><span>{event.id} / {event.kind}</span><span>{event.timing}</span></div>
                <div className="event-main"><div><h3>{event.title}</h3><p>{event.detail}</p></div><span className="event-arrow"><ArrowUpRight size={22} /></span></div>
                <div className="event-note"><span>IN THE WORKSHOP QUEUE</span><span>RSVP OPENS WHEN DATES ARE SET</span></div>
              </article>
            ))}
          </div>
          <aside className="social-panel">
            <div className="social-head"><span>USC DFA ARCHIVE / LIVE EMBED</span><Asterisk size={22} /></div>
            <div className="social-window social-window--instagram">
              <div className="instagram-intro">
                <span className="instagram-mark">✳</span>
                <div><p className="eyebrow">THE USC CHAPTER'S PUBLIC ACCOUNT</p><h3>@usc.dfa</h3></div>
                <p className="instagram-context">The chapter's Design for America archive, now a window into the relaunch.</p>
              </div>
              <p className="instagram-fallback">Recent posts load from Instagram. If this embed is blocked in your browser, open the profile directly.</p>
              <a href="https://www.instagram.com/usc.dfa/" target="_blank" rel="noreferrer" className="social-follow">OPEN @USC.DFA ON INSTAGRAM <ArrowUpRight size={17} /></a>
              <div className="instagram-embed-frame">
                <iframe
                  src="https://www.instagram.com/usc.dfa/embed/"
                  title="Live Instagram profile and recent posts from USC Design for America"
                  loading="lazy"
                  referrerPolicy="strict-origin-when-cross-origin"
                  allow="encrypted-media; picture-in-picture; web-share"
                />
              </div>
            </div>
            <div className="social-foot"><span>PUBLIC PROFILE EMBED</span><span>UPDATES WHEN INSTAGRAM LOADS</span></div>
          </aside>
        </div>
      </section>

      <section className="join" id="join">
        <div className="join-orbit join-orbit--one" />
        <div className="join-orbit join-orbit--two" />
        {STICKER_IMAGE && <img className="join-sticker" src={STICKER_IMAGE} alt="" />}
        <div className="join-top"><span>(06)</span><span>OPEN CALL / FALL 2026</span></div>
        <div className="join-content">
          <p className="eyebrow">YOU SHOULD BE HERE</p>
          <h2>BRING<br />YOUR<br /><i>WEIRD IDEA.</i></h2>
          <p className="join-copy">Applications for our first new cohort open soon. Follow the chapter account for relaunch updates, or explore the global network while the new studio takes shape.</p>
          <div className="join-actions">
            <a className="magnetic-link" href="https://www.instagram.com/usc.dfa/" target="_blank" rel="noreferrer">
              <span>FOLLOW THE RELAUNCH</span><ArrowUpRight size={23} />
            </a>
            <a className="text-link" href="https://www.world-studios.org/" target="_blank" rel="noreferrer">EXPLORE THE NETWORK <ArrowUpRight size={16} /></a>
          </div>
        </div>
        <div className="join-footer"><span>USC / LOS ANGELES / EARTH</span><span>© 2026 WORLD STUDIOS USC</span></div>
      </section>
    </main>
  );
}

function HeroGraphic() {
  return (
    <div className="hero-graphic" aria-hidden="true">
      <div className="hero-sun" />
      <div className="hero-slice hero-slice--one" />
      <div className="hero-slice hero-slice--two" />
      <div className="hero-wire hero-wire--one" />
      <div className="hero-wire hero-wire--two" />
      <span className="hero-graphic-type">↗<br />↙</span>
    </div>
  );
}

function ProcessGraphic() {
  return (
    <div className="process-graphic" aria-hidden="true">
      <div className="paper paper--yellow">WHY<br />NOT?</div>
      <div className="paper paper--red">TRY<br />THIS</div>
      <div className="paper paper--blue" />
      <div className="pencil" />
      <div className="clip">✳</div>
    </div>
  );
}
